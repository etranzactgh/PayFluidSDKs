package org.etz.payfluid.model;

public class SecZoneResponseBody {

    String approvalCode;
    String cmd;
    String datetime;
    long kekExpiry;
    long macExpiry;
    String mobile;
    String resultCode;
    String resultMessage;
    String session;

    // Getters
    public String getApprovalCode() {
        return approvalCode;
    }

    public String getCmd() {
        return cmd;
    }

    public String getDatetime() {
        return datetime;
    }

    public long getKekExpiry() {
        return kekExpiry;
    }

    public long getMacExpiry() {
        return macExpiry;
    }

    public String getMobile() {
        return mobile;
    }

    public String getResultCode() {
        return resultCode;
    }

    public String getResultMessage() {
        return resultMessage;
    }

    public String getSession() {
        return session;
    }

    //Setters
    public void setApprovalCode(String approvalCode) {
        this.approvalCode = approvalCode;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public void setKekExpiry(long kekExpiry) {
        this.kekExpiry = kekExpiry;
    }

    public void setMacExpiry(long macExpiry) {
        this.macExpiry = macExpiry;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    public void setSession(String session) {
        this.session = session;
    }
}