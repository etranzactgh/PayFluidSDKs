package org.etz.payfluid.model;

public class SaveTransReqBody {
    
    private String trans_ref, session_id;

    //Getters
    public String getSession_id() {
        return session_id;
    }

    public String getTrans_ref() {
        return trans_ref;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public void setTrans_ref(String trans_ref) {
        this.trans_ref = trans_ref;
    }
}