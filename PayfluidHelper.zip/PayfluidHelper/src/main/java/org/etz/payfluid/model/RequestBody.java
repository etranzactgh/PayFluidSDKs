package org.etz.payfluid.model;

public class RequestBody {
    String cmd, datetime, mobile;

    //Getters
    public String getCMD(){
        return cmd;
    }

    public String getdatetime(){
        return datetime;
    }

    public String getMobile(){
        return mobile;
    }

    //Setters
    public void setCMD(String cmd){
        this.cmd = cmd;
    }

    public void setdatetime(String datetime){
        this.datetime = datetime;
    }

    public void setMobile(String mobile){
        this.mobile = mobile;
    }

    public String toString(){
        return "Request Body [ cmd : "+cmd+", datetime : "
                                +datetime+", mobile: "+mobile+"]";
    }
}