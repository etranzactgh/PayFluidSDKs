package org.etz.payfluid.model;

public class ExtraInput {
    String label, placeholder, type;
    ExtraInputOptions[] options;
    boolean required;

    //Getters
    public String getLabel() {
        return label;
    }

    public ExtraInputOptions[] getOptions() {
        return options;
    }

    public String getPlaceholder() {
        return placeholder;
    }

    public String getType() {
        return type;
    }

    public boolean isRequired() {
        return required;
    }

    //Setters
    public void setLabel(String label) {
        this.label = label;
    }

    public void setOptions(ExtraInputOptions[] options) {
        this.options = options;
    }

    public void setPlaceholder(String placeholder) {
        this.placeholder = placeholder;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public void setType(String type) {
        this.type = type;
    }
}

// {
//     "label":"Church Membership ID",
//     "placeHolder":"Membership ID #",
//     "type":"input",
//     "options":[{"k":"","v":""}],
//     "required":true
// }