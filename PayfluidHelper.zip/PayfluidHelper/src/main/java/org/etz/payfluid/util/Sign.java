package org.etz.payfluid.util;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.Formatter;
import javax.crypto.SecretKey;

public class Sign {

    private static final String CONTENT_CHARSET = "UTF-8";

    // HMAC
    private static final String HMAC_ALGORITHM = "HmacSHA256";

    // This is an array for creating hex chars
    static final char[] HEX_TABLE = new char[]{
        '0', '1', '2', '3', '4', '5', '6', '7',
        '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

public static void main(String[] args) throws SignatureException {
    //       System.out.println(new Sign().getMac("testW6PX3ZBT_xDeKxBeg=Fr+2U5!3-B@uFJvSk7*&rf", "W6PX3ZBT_xDeKxBeg=Fr+2U5!3-B@uFJvSk7*&rf"));
            // System.out.println(new Sign().verifyMac("testsW6PX3ZBT_xDeKxBeg=Fr+2U5!3-B@uFJvSk7*&rf", "W6PX3ZBT_xDeKxBeg=Fr+2U5!3-B@uFJvSk7*&rf", "r6ZkdwP3lgP7Ply61GPr/7FdV6D6pKVX8kRK5ylAfUY="));
            System.out.println(get_SHA_256_with_secret("1.0GHS2020-01-14T12:06:58.491+0000testn2sethsebeh@gmail.comen0554538775Seth Sebeh-Kusicb2529b92b0477sereews333http://localhost:8089/#/client5ec50712-9df5-4f93-9e85-1f21c7401667http://payfluid.herokuapp.com/payfluid/ext/api/cupay", "6b3d7c3c35c3c5dc536ca8849b36d9ca"));
            System.out.println(sha256WithKey("1.0GHS2020-01-14T12:06:58.491+0000testn2sethsebeh@gmail.comen0554538775Seth Sebeh-Kusicb2529b92b0477sereews333http://localhost:8089/#/client5ec50712-9df5-4f93-9e85-1f21c7401667http://payfluid.herokuapp.com/payfluid/ext/api/cupay", "6b3d7c3c35c3c5dc536ca8849b36d9ca"));
            System.out.println(hashMac256WithKey("1.0GHS2020-01-14T12:06:58.491+0000testn2sethsebeh@gmail.comen0554538775Seth Sebeh-Kusicb2529b92b0477sereews333http://localhost:8089/#/client5ec50712-9df5-4f93-9e85-1f21c7401667http://payfluid.herokuapp.com/payfluid/ext/api/cupay", "6b3d7c3c35c3c5dc536ca8849b36d9ca"));
    
    //        System.out.println(hmacDigestSimple("1.0GHS2020-01-14T12:06:58.491+0000testn2sethsebeh@gmail.comen0554538775Seth Sebeh-Kusicb2529b92b0477sereews333http://localhost:8089/#/client5ec50712-9df5-4f93-9e85-1f21c7401667http://payfluid.herokuapp.com/payfluid/ext/api/cupay", "6b3d7c3c35c3c5dc536ca8849b36d9ca"));
            System.out.println(hmacDigestSimple("abcdef", "123456"));
    
    //9a2f416c48c9f36fafa63c85ebb4054e3ebeb82eb9f648abaa8eaa8f6e5f6263
        }
    
        public static String getSHA256(String input) {
            String toReturn = null;
            try {
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                digest.reset();
                digest.update(input.getBytes("utf8"));
                toReturn = String.format("%040x", new BigInteger(1, digest.digest()));
            } catch (Exception e) {
                e.printStackTrace();
            }
    
            return toReturn;
        }
    
        public static String get_SHA_256_with_secret(String passwordToHash, String secret) {
            byte[] salt = Base64.getDecoder().decode(secret.getBytes());
            String generatedPassword = null;
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update(salt);
                byte[] bytes = md.digest(passwordToHash.getBytes());
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < bytes.length; i++) {
                    sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
                }
                generatedPassword = sb.toString();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            return generatedPassword;
        }
    
        //encryption 
        public static String sha256WithKey(String data, String secret) {
            String sign = "";
            try {
                Mac mac = Mac.getInstance("HmacSHA256");
                SecretKeySpec secretKey = new SecretKeySpec(secret.getBytes(CONTENT_CHARSET), mac.getAlgorithm());
                mac.init(secretKey);
                byte[] hash = mac.doFinal(data.getBytes(CONTENT_CHARSET));
                sign = Base64.getEncoder().encodeToString(hash);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(Sign.class.getName()).log(Level.SEVERE, null, ex);
            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(Sign.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvalidKeyException ex) {
                Logger.getLogger(Sign.class.getName()).log(Level.SEVERE, null, ex);
            }
            return sign;
        }
    
        public static String hashMac256WithKey(String text, String secretKey) {
            try {
                Key sk = new SecretKeySpec(secretKey.getBytes(), HASH_ALGORITHM);
                Mac mac = Mac.getInstance(sk.getAlgorithm());
                mac.init(sk);
                final byte[] hmac = mac.doFinal(text.getBytes());
                return toHexString(hmac);
            } catch (NoSuchAlgorithmException e1) {
                // throw an exception or pick a different encryption method
                //throw new SignatureException("error building signature, no such algorithm in device " + HASH_ALGORITHM);
            } catch (InvalidKeyException e) {
                //throw new SignatureException( "error building signature, invalid key " + HASH_ALGORITHM);
            }
            return null;
        }
    
        private static final String HASH_ALGORITHM = "HmacSHA256";
    
        public static String toHexString(byte[] bytes) {
            StringBuilder sb = new StringBuilder(bytes.length * 2);
    
            Formatter formatter = new Formatter(sb);
            for (byte b : bytes) {
                formatter.format("%02x", b);
            }
    
            return sb.toString();
        }
    
        public static String getSHA512(String input) {
    
            String toReturn = null;
            try {
                MessageDigest digest = MessageDigest.getInstance("SHA-512");
                digest.reset();
                digest.update(input.getBytes("utf8"));
                toReturn = String.format("%040x", new BigInteger(1, digest.digest()));
            } catch (Exception e) {
                e.printStackTrace();
            }
    
            return toReturn;
        }
    
        public static String getMac(String data, String secret) {
            String sign = "";
            try {
                Mac mac = Mac.getInstance(HMAC_ALGORITHM);
                SecretKeySpec secretKey = new SecretKeySpec(secret.getBytes(CONTENT_CHARSET), mac.getAlgorithm());
                mac.init(secretKey);
                byte[] hash = mac.doFinal(data.getBytes(CONTENT_CHARSET));
                sign = Base64.getEncoder().encodeToString(hash);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(Sign.class.getName()).log(Level.SEVERE, null, ex);
            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(Sign.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvalidKeyException ex) {
                Logger.getLogger(Sign.class.getName()).log(Level.SEVERE, null, ex);
            }
            return sign;
        }
    
        public static boolean verifyMac(String data, String secret, String mac) {
            String calculatedMac = getMac(data, secret);
            if (calculatedMac.equals(mac)) {
                return true;
            }
            return false;
        }
    
        //BT method to do sha
        public static String getShaBT(String keyy, String data) {
            try {
                byte[] b = fromHexString(keyy, 0, keyy.length());
    
                SecretKey key = new SecretKeySpec(b, "HmacSHA256");
                Mac mac = Mac.getInstance("HmacSHA256");
    
                mac.init(key);
    
                mac.update(data.getBytes("ISO-8859-1"));
                byte[] arr = mac.doFinal();
    
                String hashValue = hex(arr);
                return hashValue;
            } catch (Exception ex) {
                Logger.getLogger(Sign.class.getName()).log(Level.SEVERE, null, ex);
            }
            return null;
        }
    
        public static byte[] fromHexString(String s, int offset, int length) {
            if ((length % 2) != 0) {
                System.out.println("nullllll");
                return null;
            }
            System.out.println("not nulllll");
            byte[] byteArray = new byte[length / 2];
            int j = 0;
            int end = offset + length;
            for (int i = offset; i < end; i += 2) {
                int high_nibble = Character.digit(s.charAt(i), 16);
                int low_nibble = Character.digit(s.charAt(i + 1), 16);
                if (high_nibble == -1 || low_nibble == -1) {
                    // illegal format
                    return null;
                }
                byteArray[j++] = (byte) (((high_nibble << 4) & 0xf0) | (low_nibble & 0x0f));
            }
            return byteArray;
        }
    
        static String hex(byte[] input) {
            // create a StringBuffer 2x the size of the hash array
            StringBuffer sb = new StringBuffer(input.length * 2);
    
            // retrieve the byte array data, convert it to hex
            // and add it to the StringBuffer
            for (int i = 0; i < input.length; i++) {
                sb.append(HEX_TABLE[(input[i] >> 4) & 0xf]);
                sb.append(HEX_TABLE[input[i] & 0xf]);
            }
            return sb.toString();
        }
    
        public static String hmacDigestSimple(String data, String keyy) {
            byte[] mac = null;
            String hashValue = "";
            try {
    
                byte[] b = (keyy).getBytes("UTF-8");
                SecretKey key = new SecretKeySpec(b, "HmacSHA256");
                Mac m = Mac.getInstance("HmacSHA256");
                m.init(key);
    
                //m.update(data.getBytes("ISO-8859-1"));
                m.update(data.getBytes("UTF-8"));
                mac = m.doFinal();
    
                hashValue = hex(mac);
            } catch (Exception e) {
                //l.error(e, e);
            }
            return hashValue;
        }
    
}