package org.etz.payfluid;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.etz.payfluid.model.PayLinkReqBody;
import org.etz.payfluid.model.PayLinkResponseBody;
import org.etz.payfluid.model.RequestBody;
import org.etz.payfluid.model.SecZoneResponseBody;
import org.etz.payfluid.util.General;
import org.etz.payfluid.util.RSAUtils;
import org.etz.payfluid.util.Sign;

public class PayFluidHelper {

    public static void main(String[] args) throws IllegalBlockSizeException, InvalidKeyException,
            NoSuchPaddingException, BadPaddingException, NoSuchAlgorithmException, IOException,
            URISyntaxException {

        //Testing the public methods: 1. callCreateSecureZoneStr 2. getPayLink 3. fetchPayLink

        //Declare all parameters required for the requests
        String id = "04040405";
        String mobileNumber = "+233542023469";
        String loginParams = "781e5e245d69b566979b86e28d23f2c7"; //
        // String loginParams = "jflkajkjsdljdflskjflksdjijlkjs"; //
        String RSAPublicKey = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAI8LN/AC3XOz23O7v/de/jbYFQYrbeFqQVaIYpFRIR+YSCWfHlcl3PNKy7Vniq+rWG8KPN8uw2RUU/1qvoZP3xsCAwEAAQ==";  //
        // String RSAPublicKey = "tjeahkjwhejhskjhkjshd";
        String reference = generateReference();
        double amount = 0.1;
        String currency = "GHs";
        String descr = "testn2";
        String email = "you@yourmail.com";
        String clientMobileNumber = "+233242531277";
        String clientName = "Abiodun Taiwo";
        //Can be anything
        String otherInfo = "cb01d865-b23d-4b44-a082-cb2529b92b04";
        String redirectURL = "https://yourwebsite.com/redirect/";
        String callbackURL = "https://yourwebsite.com/callBacks/";


        // 1. Test callCreateSecureZoneStr method
        // String[] response = callCreateSecureZoneStr(mobileNumber, id, loginParams, RSAPublicKey);

        // //2. Test getPayLink standalone method
        // if(response[0] != null){
        //     String responseStr = String.format("Response from createSecureZone - Standalone:\n\nKek: %s \nSecZone Json Response: %s\n",
        //                             response[0], response[1]);
        //     System.out.println(responseStr);

        //     String sessionID = getGson().fromJson(response[1], SecZoneResponseBody.class).getSession();

        //     String transRef = generateReference();
        //     String datetTime = General.fetchCurDate("yyyy-MM-dd'T'hh:mm:ss.SSSZ");

        //     //Prepare json
        //     String trnxJson = "{"+
        //         "\"amount\":"+amount+","+
        //         "\"currency\":\""+currency+"\","+
        //         "\"datetime\":\""+datetTime+"\","+
        //         "\"descr\":\""+descr+"\","+
        //         "\"email\":\""+email+"\","+
        //         "\"lang\":\"en\","+
        //         "\"mobile\":\""+clientMobileNumber+"\","+
        //         "\"name\":\""+clientName+"\","+
        //         "\"otherInfo\":\""+otherInfo+"\","+
        //         "\"reference\":\""+transRef+"\","+
        //         "\"responseRedirectURL\":\""+redirectURL+"\","+
        //         "\"session\":\""+sessionID+"\","+
        //         "\"trxStatusCallbackURL\":\""+callbackURL+"\""+
        //     "}";

        //     //Get RSAKey & Salt to pass to make getPaymentLink method
        //     String[] keySalt = response[0].split("\\.");
        //     String RSAKey = keySalt[0];
        //     String salt = keySalt[1];
        //     String outputStr = String.format("\nRSAKey & Salt received from createSecureZone header 'kek'\n"+
        //                     "RSAKey: %s \nSalt: %s\n", RSAKey, salt);
        //     System.out.println(outputStr);
        //     System.out.println("\nResponse from getPaymentLink - standalone:\n\n"+getPayLink(RSAKey, salt, trnxJson));
        // }else if(response[1].startsWith("000")){
        //     System.out.println(response[1].substring(3));
        // }else {
        //     //Display error to user
        //     Gson gson = getGson();
        //     SecZoneResponseBody s = gson.fromJson(response[1], SecZoneResponseBody.class);
        //     String outputStr = String.format("Result Code: %s\nMessage: %s", s.getResultCode(), s.getResultMessage());
        //     System.out.println(outputStr);
        // }

        //3. Test fetchPayLink
        String[] response = fetchPayLink(id, reference, mobileNumber, loginParams, RSAPublicKey, amount, currency, descr, email,
                clientMobileNumber, clientName, otherInfo, redirectURL, callbackURL);

        System.out.println("\nResponse from fetchPayLink - combo of createSecureZone & getPayLink as one method:\n\n"+
            "0 - Payload:: "+response[0]+"\n1 - Session ID from Create Secure Zone:: "+response[1]
        );
    }

    //1. Create Secure Zone - Standalone
    /**
     *
     * @param mobileNumber
     * @param id
     * @param loginParams
     * @param RSAPublicKey
     * @return String[2] response :
     *          kek = response[0] - This is null if an error occurs
     *          jsonResponse = response[1]
     * @throws IllegalBlockSizeException
     * @throws InvalidKeyException
     * @throws NoSuchPaddingException
     * @throws BadPaddingException
     * @throws NoSuchAlgorithmException
     * @throws IOException
     *
     */
    public static String[] callCreateSecureZoneStr(String mobileNumber, String id,
            String loginParams, String RSAPublicKey)
            throws
            IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException,
            BadPaddingException, NoSuchAlgorithmException, IOException{

        //Check internet connection
        if(General.hasInternet()){
            //Check base64 validity of Key
            if(General.checkValidBase64(RSAPublicKey)){
                //Get current date in format specified in the docs
                String curDate = General.fetchCurDate("yyyyMMddHHmmssSSS");

                //Mobile number must have country code included
                String jsonReq = "{\"cmd\": \"getSecureParams\"," + "\"datetime\": \"" + curDate
                            + "\", \"mobile\": \""+mobileNumber+"\"}";
                return createSecureZoneStr(jsonReq, id, loginParams, RSAPublicKey, curDate);
            }else {
                return new String[]{null, "000Error: Invalid Public Key."};
            }
        }else {
            return new String[]{null, "000Error: No internet connection"};
        }

    }

    //2. Create Secure Zone & Get Payment Link in one step
    public static String[] fetchPayLink(
            String id, String reference, String mobileNumber, String loginParams, String RSAPublicKey,
            double amount, String currency, String descr, String email, String clientMobileNumber,
            String clientName, String otherInfo, String redirectURL, String callbackURL
            ) throws
            IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, BadPaddingException,
            NoSuchAlgorithmException, IOException,  URISyntaxException{

        String outputStr = null;
        String sessionID = null;
        String datetTime = General.fetchCurDate("yyyy-MM-dd'T'hh:mm:ss.SSSZ");


        //Check internet connection
        if(General.hasInternet()){
            //Check RSAPubicKey for Base64 validity
            if(General.checkValidBase64(RSAPublicKey)){
                String[] response = callCreateSecureZone(mobileNumber, id, loginParams, RSAPublicKey);
                if(response[0].equalsIgnoreCase("error")){
                    outputStr = "Error: "+response[1];
                    // System.out.println("Error: "+response[1]);
                }else {
                    //Check currency
                    if(General.checkCurrency(currency)){
                        sessionID = buildSecZoneRespBody(response[2]).getSession();
                        // Generate a unique reference for each transaction

                        //Prepare json body for request
                        String trnxJson = "{"+
                            "\"amount\":"+amount+","+
                            "\"currency\":\""+currency+"\","+
                            "\"datetime\":\""+datetTime+"\","+
                            "\"descr\":\""+descr+"\","+
                            "\"email\":\""+email+"\","+
                            "\"lang\":\"en\","+
                            "\"mobile\":\""+clientMobileNumber+"\","+
                            "\"name\":\""+clientName+"\","+
                            "\"otherInfo\":\""+otherInfo+"\","+
                            "\"reference\":\""+reference+"\","+
                            "\"responseRedirectURL\":\""+redirectURL+"\","+
                            "\"session\":\""+sessionID+"\","+
                            "\"trxStatusCallbackURL\":\""+callbackURL+"\""+
                        "}";

                        // paymentLink = getPayLink(response[1], response[0], sessionID, trnxJson);
                        outputStr =  getPayLink(response[1], response[0], trnxJson);
                        //Do as desired with Payment Link
                        // System.out.println(paymentLink);
                    }else {
                        outputStr = "Error: Currency not accepted.";
                    }

                }
                // return paymentLink;
            }else {
                outputStr = "Error: Invalid Public Key.";
            }
        }else {
            outputStr = "Error: No internet connection.";
        }

        //sessionID is returned as part of paymeent link because you will need it to authenticate callback, redirect and transaction status check calls
        //Please save this for future use.
        return new String[] {outputStr, sessionID};
    }

    private static String[] createSecureZoneStr(String jsonReq, String id,
                String loginParams, String RSAPublicKey, String curDate)
            throws
            IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException,
            BadPaddingException, NoSuchAlgorithmException, IOException
    {
        Gson gson = getGson();

        RequestBody reqBody = gson.fromJson(jsonReq, RequestBody.class);
        String jsonString = gson.toJson(reqBody);
        //Endpoint to Create Secure Zone is assigned to url variable
        String url = "https://payfluid-api.herokuapp.com/payfluid/ext/api/secureCredentials";

        //Appropriate parameters are passed to begin actual POST request
        return General.sendPOST(jsonString, curDate, url, id, loginParams, RSAPublicKey);
    }

    private static SecZoneResponseBody buildSecZoneRespBody(String jsonStr){
        return getGson().fromJson(jsonStr, SecZoneResponseBody.class);
    }

    private static PayLinkResponseBody buildPayLinkRespBody(String jsonStr){
        return getGson().fromJson(jsonStr, PayLinkResponseBody.class);
    }

    private static Gson getGson(){
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setPrettyPrinting();
        return gsonBuilder.create();
    }

    /**
     * Returns a String array containing in order:
     *  1. Salt for SHA-256 in the next call ie. Get Payment Link
     *  2. RSA Key to be used for encrypting the request json body for the next call ie. Get Payment Link
     *  3. Json Response Body from this call. Below is a sample response:
     *  {
     *       "approvalCode":"509338",
     *       "cmd":"getSecureParams",
     *       "datetime":"2019-11-21T17:19:35.272Z",
     *       "kekExpiry":120000,
     *       "macExpiry":7000,
     *       "resultCode":"00",
     *       "resultMessage":"Secure credentials created",
     *       "session":"cb01d865-b23d-4b44-a082-cb2529b92b04"
     *   }
     *
     *
     * @return
     * @throws IllegalBlockSizeException
     * @throws InvalidKeyException
     * @throws NoSuchPaddingException
     * @throws BadPaddingException
     * @throws NoSuchAlgorithmException
     * @throws IOException
     */
    private static String[] callCreateSecureZone(String mobileNumber, String id,
                String loginParams, String RSAPublicKey)
            throws
                IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException,
                BadPaddingException, NoSuchAlgorithmException, IOException{

        //Get current date in format specified in the docs
        String curDate = General.fetchCurDate("yyyyMMddHHmmssSSS");

        //Mobile number must have country code included
        String params = "{\"cmd\": \"getSecureParams\"," + "\"datetime\": \"" + curDate
                    + "\", \"mobile\": \""+mobileNumber+"\"}";

        //Call to Create Secure Zone is performed here passing test parameters defined above:
        String[] response = createSecureZone(params, id, loginParams, RSAPublicKey, curDate);

        SecZoneResponseBody secZoneResponseBody  = getGson().fromJson(response[1], SecZoneResponseBody.class);
        // SecZoneResponseBody secZoneResponseBody  = gson.fromJson(response[1], SecZoneResponseBody.class);
        if(secZoneResponseBody.getResultCode().equals("00")){
            String kek = response[0];

            String RSAKey = null;
            String salt = null;
            StringBuilder RSAKeyBuilder = new StringBuilder();
            // StringBuilder saltKeyBuilder = new StringBuilder();
            if(kek != null){
                for(int i=0; i<kek.length(); i++){
                    if(kek.charAt(i) != '.'){
                        RSAKeyBuilder.append(kek.charAt(i));
                    }else {
                        RSAKey = RSAKeyBuilder.toString();
                        salt = kek.substring(i+1, kek.length());
                        break;
                    }
                }
            }
            return new String[]{salt, RSAKey, response[1]};
        }else {
            return new String[]{"error", secZoneResponseBody.getResultMessage()};
        }
    }

    /**
     * Performs POST request to the Create Secure Zone Endpoint of PayFluid
     * Returns a String array of 'kek' and json return body in that order
     *
     * @param params
     * @param id
     * @param loginParams
     * @param RSAPublicKey
     * @return
     * @throws IllegalBlockSizeException
     * @throws InvalidKeyException
     * @throws NoSuchPaddingException
     * @throws BadPaddingException
     * @throws NoSuchAlgorithmException
     * @throws IOException
     */
    private static String[] createSecureZone(
            String params, String id, String loginParams, String RSAPublicKey, String curDate) throws
            IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException,
            BadPaddingException, NoSuchAlgorithmException, IOException
    {
        Gson gson = getGson();

        RequestBody reqBody = gson.fromJson(params, RequestBody.class);
        String jsonString = gson.toJson(reqBody);
        //Endpoint to Create Secure Zone is assigned to url variable
        String url = "https://payfluid-api.herokuapp.com/payfluid/ext/api/secureCredentials";

        //Appropriate parameters are passed to begin actual POST request
        return General.sendPOST(jsonString, curDate, url, id, loginParams, RSAPublicKey);
    }

    //This is a public method and can  be
    public static String getPayLink(String RSAKey, String salt, String jsonReq)
            throws
            IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException,
            BadPaddingException, NoSuchAlgorithmException, IOException
    {
        //Check internet
        if(General.hasInternet()){
            Gson gson = getGson();

            // PayLinkReqBody reqBody = gson.fromJson(params, PayLinkReqBody.class);
            PayLinkReqBody reqBody = gson.fromJson(jsonReq, PayLinkReqBody.class);
            //Check Key for Base64 validity
            if(General.checkValidBase64(RSAKey)){
                //Check currency if it is GHs
                if(General.checkCurrency(reqBody.getCurrency())){
                    String jsonString = gson.toJson(reqBody);
                    String url = "https://payfluid-api.herokuapp.com/payfluid/ext/api/getPayLink";

                    String strToHash = prepAmount(reqBody.getAmount()) + reqBody.getCurrency() +
                                    // reqBody.getCustomTxn().toString()+
                                    reqBody.getDatetime() + reqBody.getDescr() + reqBody.getEmail() + reqBody.getLang()+
                                    reqBody.getMobile() + reqBody.getName() + reqBody.getOtherInfo()+
                                    reqBody.getReference() + reqBody.getResponseRedirectURL() +reqBody.getSession()+
                                    reqBody.getTrxStatusCallbackURL();

                    String hashedStr = Sign.hmacDigestSimple(strToHash, salt);
                    //Encrypt hashed String
                    String signature =
                            Base64.getEncoder().encodeToString(RSAUtils.encrypt(hashedStr, RSAKey));
                    return General.sendPOST(jsonString, url, signature);
                }else {
                    return "Error: Currency not accepted.";
                }
            }else {
                return "Error: Invalid Public Key.";
            }
        }else {
            return "Error: No internet connection";
        }

        // return null;
    }

    //Whole amounts must be returned without trailing 0 eg. 1.0 should be 1 instead
    private static String prepAmount(double amount){
        String strVal = String.valueOf(amount);
        if(amount%1 == 0){
            return strVal.split("\\.")[0];
        }
        return strVal;
    }

    private static String generateReference(){
        //Replace this with your own format for generating references
        int max = 100000, min = 10000;
        int random_int = (int)(Math.random() * (max - min + 1) + min);

        return String.valueOf(random_int);
    }
}
