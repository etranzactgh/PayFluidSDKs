package org.etz.payfluid.model;

public class PayLinkReqBody {
    double amount;
    String currency, datetime, descr, email, lang, mobile, name, otherInfo, 
            reference, responseRedirectURL, session, trxStatusCallbackURL;
    CustomTxt customTxn;

    //Getters
    public double getAmount() {
        return amount;
    }

    public String getCurrency() {
        return currency;
    }

    public CustomTxt getCustomTxn() {
        return customTxn;
    }

    public String getDatetime() {
        return datetime;
    }

    public String getDescr() {
        return descr;
    }

    public String getEmail() {
        return email;
    }

    public String getLang() {
        return lang;
    }

    public String getMobile() {
        return mobile;
    }

    public String getName() {
        return name;
    }

    public String getOtherInfo() {
        return otherInfo;
    }

    public String getReference() {
        return reference;
    }

    public String getResponseRedirectURL() {
        return responseRedirectURL;
    }

    public String getSession() {
        return session;
    }

    public String getTrxStatusCallbackURL() {
        return trxStatusCallbackURL;
    }

    //Settters

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setCustomTxn(CustomTxt customTxn) {
        this.customTxn = customTxn;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOtherInfo(String otherInfo) {
        this.otherInfo = otherInfo;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public void setResponseRedirectURL(String responseRedirectURL) {
        this.responseRedirectURL = responseRedirectURL;
    }

    public void setSession(String session) {
        this.session = session;
    }

    public void setTrxStatusCallbackURL(String trxStatusCallbackURL) {
        this.trxStatusCallbackURL = trxStatusCallbackURL;
    }

    //Add toString
}

// Sample
// {

//     "amount":1.0,

//     "currency":"GHS",

//     "datetime":"2019-11-21T17:19:36.021Z",

//     "descr":"testn2",

//     "email":"biodunolrj@gmail.com",

//     "lang":"en",

//     "mobile":"9412274444",

//     "name":"Abiodun Taiwo",

//     "otherInfo":"cb01d865-b23d-4b44-a082-cb2529b92b04",

//     "reference":"77333",

//     "responseRedirectURL":"http://mywebsite.com/payResponse",

//     "session":"cb01d865-b23d-4b44-a082-cb2529b92b04",

//     "trxStatusCallbackURL":"http://mywebsite.com/backendProcess",

//     "customTxn": {}

// }