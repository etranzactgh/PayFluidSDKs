package org.etz.payfluid.model;

public class ExtraInputOptions {
    String k, v;

    public String getK() {
        return k;
    }

    public String getV() {
        return v;
    }

    public void setK(String k) {
        this.k = k;
    }

    public void setV(String v) {
        this.v = v;
    }
}

// {
//     "k":"firstfruit",
//     "v":"First Fruit"
// }