package org.etz.payfluid.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Locale;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class General {
    private General(){}

    //createSecureZone POST
    public static String[] sendPOST(String jSonString, String curDate, String url, String id,
                        String loginParam, String RSAPublicKey) 
            throws IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, 
            BadPaddingException, IOException, NoSuchAlgorithmException {

        String[] keyResponseVals = new String[2];
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        // con.setRequestProperty("User-Agent", USER_AGENT);
        id = Base64.getEncoder().encodeToString(id.getBytes());
        con.setRequestProperty("id", id);
        String strToEncrypt = loginParam + "." + curDate;
        String encryptedString = 
                Base64.getEncoder().encodeToString(RSAUtils.encrypt(strToEncrypt, RSAPublicKey));
        // System.out.println(encryptedString);
        con.setRequestProperty("apiKey", encryptedString);
        con.setRequestProperty("Content-Type", "Application/json; charset=UTF-8");

        // For POST only - START
        con.setDoOutput(true);
        OutputStream os = con.getOutputStream();
        // Write data to
        os.write(jSonString.getBytes());
        os.flush();
        os.close();

        // For POST only - END
        int responseCode = con.getResponseCode();
        // informUser("POST Response Code :: " + responseCode);
        String kek = con.getHeaderField("kek");
        keyResponseVals[0] = kek;
        // informUser("Response "+kek);
        if (responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_CREATED) {
            // success
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // print result
            // informUser(response.toString());
            keyResponseVals[1] = response.toString();
        } else {
            informUser("POST request not worked");
        }

        return keyResponseVals;
    }

    //GetPayLink POST
    public static String sendPOST(String jSonString, String url, String signature) 
            throws IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, 
            BadPaddingException, IOException, NoSuchAlgorithmException {
        
        String outputStr = null;

        // String[] keyResponse = new String[2];
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("signature", signature);
        con.setRequestProperty("Content-Type", "Application/json; charset=UTF-8");

        // For POST only - START
        con.setDoOutput(true);
        OutputStream os = con.getOutputStream();
        // Write data to
        os.write(jSonString.getBytes());
        os.flush();
        os.close();

        // For POST only - END
        int responseCode = con.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_CREATED) {
            // success
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            outputStr = response.toString();
        } else {
            informUser("POST request not worked");
        }

        return outputStr;

        // informUser(outputStr);
    }

    public static String sendPOST(String jSonString, String url) 
            throws  IOException {
        
        String outputStr = null;
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "Application/json; charset=UTF-8");

        // For POST only - START
        con.setDoOutput(true);
        OutputStream os = con.getOutputStream();
        os.write(jSonString.getBytes());
        os.flush();
        os.close();

        int responseCode = con.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            // success
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            outputStr = response.toString();
        } else {
            informUser("POST request not worked");
        }

        informUser(outputStr);
        return outputStr;
    }

    public static String fetchCurDate(String format){
        return new SimpleDateFormat(format, Locale.US).format(new Date());
    }

    public static void sendGET(String url) throws IOException {

        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        int responseCode = con.getResponseCode();
        // informUser("GET Response Code :: " + responseCode);

        if (responseCode == HttpURLConnection.HTTP_OK) {
            // success
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }

            in.close();

            // print result
            // informUser(response.toString());
        } else {
            // informUser("GET request did not work.");
        }
    }

    public static void informUser(String info){
        System.out.println(info);
    }

    //Check internet connection
    public static boolean hasInternet(){
        try {
            URL url = new URL("http://www.google.com");
            URLConnection connection = url.openConnection();
            connection.connect();
            return true;
        }catch(UnknownHostException e){
            return false;
            // e.printStackTrace();
        }catch(MalformedURLException e){
            // return false;
            e.printStackTrace();
        }catch(IOException e){
            // return false;
            e.printStackTrace();
        }
        
        return false;
    }

    //Check currency
    public static boolean checkCurrency(String currency){
        if(currency.equalsIgnoreCase("ghs")){
            return true;
        }

        return false;
    }

    //Check base64 validity
    public static boolean checkValidBase64(String base64Str){
        String regCompr = "^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)?$";
        return base64Str.matches(regCompr);
    }
}