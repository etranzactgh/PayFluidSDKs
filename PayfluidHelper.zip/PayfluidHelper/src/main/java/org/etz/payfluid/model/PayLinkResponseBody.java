package org.etz.payfluid.model;

public class PayLinkResponseBody {
    String approvalCode, result_message, webURL, session, result_code;

    //Getters
    public String getApprovalCode() {
        return approvalCode;
    }

    public String getResult_code() {
        return result_code;
    }

    public String getResult_message() {
        return result_message;
    }

    public String getSession() {
        return session;
    }

    public String getWebURL() {
        return webURL;
    }

    //Settters
    public void setApprovalCode(String approvalCode) {
        this.approvalCode = approvalCode;
    }

    public void setResult_code(String result_code) {
        this.result_code = result_code;
    }

    public void setResult_message(String result_message) {
        this.result_message = result_message;
    }

    public void setSession(String session) {
        this.session = session;
    }

    public void setWebURL(String webURL) {
        this.webURL = webURL;
    }
    
}


//Sample 

// {
//     "approvalCode":"912446",
//     "result_message":"Processed Successfully",
//     "webURL":"https://payfluid.herokuapp.com/#/pay/LG4Yy7t",
//     "session":"d8fd780f-357d-4fe9-a07a-ba3fe14548b6",
//     "result_code":"00"
// }