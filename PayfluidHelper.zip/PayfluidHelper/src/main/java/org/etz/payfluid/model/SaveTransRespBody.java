package org.etz.payfluid.model;

public class SaveTransRespBody {
    private boolean success;
    private String message;

    //Getters
    public String getMessage() {
        return message;
    }

    public boolean isSuccess() {
        return success;
    }

    //Setters
    public void setMessage(String message) {
        this.message = message;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

}