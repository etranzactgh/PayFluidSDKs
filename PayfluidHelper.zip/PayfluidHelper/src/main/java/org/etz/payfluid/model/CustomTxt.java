package org.etz.payfluid.model;

public class CustomTxt {
    
    boolean editAmt, payLinkCanPayMultipleTimes;
    double minAmt;
    double maxAmt;
    String borderTheme, receiptSxMsg, receiptFeedbackPhone, 
        receiptFeedbackEmail, displayPicture;
    int payLinkExpiryInDays;
    ExtraInput[] xtraCustomerInput;

    //Getters
    public String getBorderTheme() {
        return borderTheme;
    }

    public String getDisplayPicture() {
        return displayPicture;
    }

    public double getMaxAmt() {
        return maxAmt;
    }

    public double getMinAmt() {
        return minAmt;
    }

    public int getPayLinkExpiryInDays() {
        return payLinkExpiryInDays;
    }

    public String getReceiptFeedbackPhone() {
        return receiptFeedbackPhone;
    }

    public String getReceiptSxMsg() {
        return receiptSxMsg;
    }

    public ExtraInput[] getXtraCustomerInput() {
        return xtraCustomerInput;
    }

    public boolean isEditAmt() {
        return editAmt;
    }

    public boolean isPayLinkCanPayMultipleTimes() {
        return payLinkCanPayMultipleTimes;
    }

    public String getReceiptFeedbackEmail() {
        return receiptFeedbackEmail;
    }

    //Setters
    public void setBorderTheme(String borderTheme) {
        this.borderTheme = borderTheme;
    }

    public void setDisplayPicture(String displayPicture) {
        this.displayPicture = displayPicture;
    }

    public void setEditAmt(boolean editAmt) {
        this.editAmt = editAmt;
    }

    public void setMaxAmt(double maxAmt) {
        this.maxAmt = maxAmt;
    }

    public void setMinAmt(double minAmt) {
        this.minAmt = minAmt;
    }

    public void setPayLinkCanPayMultipleTimes(boolean payLinkCanPayMultipleTimes) {
        this.payLinkCanPayMultipleTimes = payLinkCanPayMultipleTimes;
    }

    public void setPayLinkExpiryInDays(int payLinkExpiryInDays) {
        this.payLinkExpiryInDays = payLinkExpiryInDays;
    }

    public void setReceiptFeedbackPhone(String receiptFeedbackPhone) {
        this.receiptFeedbackPhone = receiptFeedbackPhone;
    }

    public void setReceiptSxMsg(String receiptSxMsg) {
        this.receiptSxMsg = receiptSxMsg;
    }

    public void setXtraCustomerInput(ExtraInput[] xtraCustomerInput) {
        this.xtraCustomerInput = xtraCustomerInput;
    }

    public void setReceiptFeedbackEmail(String receiptFeedbackEmail) {
        this.receiptFeedbackEmail = receiptFeedbackEmail;
    }

    // public String toString(){
    //     return "{"+
    //                 "\"editAmt\":"+editAmt+","+
    //                 "\"minAmt\":"+minAmt+","+
    //                 "\"maxAmt\":"+maxAmt+","+
    //                 "\"borderTheme\":\""+borderTheme+"\","+
    //                 "\"receiptSxMsg\":"+receiptSxMsg+","+
    //                 "\"receiptFeedbackPhone\":\"233241234567\","+
    //                 "\"receiptFeedbackEmail\":\""+receiptFeedbackEmail+"\","+
    //                 "\"payLinkExpiryInDays\":"+payLinkExpiryInDays+","+
    //                 "\"payLinkCanPayMultipleTimes\":"+payLinkCanPayMultipleTimes+","+
    //                 "\"displayPicture\":\""+displayPicture+"\","+
    //                 "\"xtraCustomerInput\":\""+displayPicture+"\","+
            
    //         //     "xtraCustomerInput": [
    //         //         {
    //         //             "label":"Church Membership ID",
    //         //             "placeHolder":"Membership ID #",
    //         //             "type":"input",
    //         //             "options":[{"k":"","v":""}],
    //         //             "required":true
    //         //         },
    //         //         {
    //         //             "label":"Offering Type",
    //         //             "placeHolder":"Offering Type2",
    //         //             "type":"select",
    //         //             "options": [
    //         //                 {
    //         //                     "k":"firstfruit",
    //         //                     "v":"First Fruit"
    //         //                 },
    //         //                 {
    //         //                     "k":"tithe",
    //         //                     "v":"Tithe"
    //         //                 },
    //         //                 {
    //         //                     "k":"harvest",
    //         //                     "v":"Harvest"
    //         //                 }
    //         //             ],
    //         //             "required":true
    //         //         }
    //         //     ]
    //         // }
    // }
}

// Sample
// {

//     "editAmt":true,

//     "minAmt":5.00,

//     "maxAmt":1500.50,

//     "borderTheme":"#9c27b0",

//     "receiptSxMsg":"Please login to www.nestle.com, type in your payment reference number to download your order form. Contact the below number if there are any challenges",

//     "receiptFeedbackPhone":"233241234567",

//     "receiptFeedbackEmail":"order@nestle.com",

//     "payLinkExpiryInDays":15,

//     "payLinkCanPayMultipleTimes":true,

//     "displayPicture":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQbozpnBbX46cLB7OrTw977TArZ1jIDExRBolJxBXf8dVMjSId--SxEA",

//     "xtraCustomerInput": [
//         {
//             "label":"Church Membership ID",
//             "placeHolder":"Membership ID #",
//             "type":"input",
//             "options":[{"k":"","v":""}],
//             "required":true
//         },
//         {
//             "label":"Offering Type",
//             "placeHolder":"Offering Type2",
//             "type":"select",
//             "options": [
//                 {
//                     "k":"firstfruit",
//                     "v":"First Fruit"
//                 },
//                 {
//                     "k":"tithe",
//                     "v":"Tithe"
//                 },
//                 {
//                     "k":"harvest",
//                     "v":"Harvest"
//                 }
//             ],
//             "required":true
//         }
//     ]
// }